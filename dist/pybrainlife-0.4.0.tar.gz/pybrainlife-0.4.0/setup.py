# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pybrainlife', 'pybrainlife.data', 'pybrainlife.vis']

package_data = \
{'': ['*']}

install_requires = \
['bctpy>=0.5.2,<0.6.0',
 'jgf>=0.2.2,<0.3.0',
 'numpy>=1.9.3,<2.0.0',
 'pandas>=1.4.2,<2.0.0',
 'requests>=2.27.1,<3.0.0',
 'scikit-learn>=1.0.2,<2.0.0',
 'scipy>=1.8.0,<2.0.0',
 'seaborn>=0.11.2,<0.12.0']

setup_kwargs = {
    'name': 'pybrainlife',
    'version': '0.4.0',
    'description': 'This project is a collection of functions that are useful for analyzing MRI data derivatives generated on brainlife.io',
    'long_description': None,
    'author': 'Brad Caron',
    'author_email': 'bacaron245@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.9',
}


setup(**setup_kwargs)
